<div class="slide-footer">
    <div class="cover-at-logo">
        <img src="/assets/images/at-transparent-logo.svg" alt="at logo">
    </div>
    <span>All concepts within this document remain the exclusive property of About Today. Visit <a href="https://www.abouttoday.com.au" target="_blank">abouttoday.com.au</a> to view our full copyright policy.</span>
</div>