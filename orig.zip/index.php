<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="/assets/css/global.css" />
    <link rel="stylesheet" href="/assets/css/styleguide.css" />
    <link rel="stylesheet" href="/assets/css/style.css" />
  </head>
  <body>
    <div class="dashboard-new">
      <div class="nav-header">
        <div class="acc">
          <div class="frame">
            <img class="user-user" src="https://c.animaapp.com/ct0n38lD/img/user---user-01.svg" />
            <div class="div">
              <div class="text-wrapper">My Account</div>
              <div class="frame-2">
                <div class="text-wrapper-2">Shaun Ryan</div>
                <div class="text-wrapper-3">caret-down</div>
              </div>
            </div>
          </div>
        </div>
        <div class="layer">
          <img class="vector" src="https://c.animaapp.com/ct0n38lD/img/vector.svg" />
          <img class="group" src="https://c.animaapp.com/ct0n38lD/img/group@2x.png" />
        </div>
      </div>
      <footer class="footer"><p class="p">© Fisher 2025. All rights reserved.</p></footer>
      <p class="privacy-policy-terms">
        <span class="span">Privacy Policy</span>
        <span class="text-wrapper-4">&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;</span>
        <span class="span">Terms and Conditions</span>
      </p>
      <div class="frame-3">
        <div class="frame-4">
          <div class="text-wrapper-5">Welcome, Shaun!</div>
          <p class="text-wrapper-6">Manage, assess, and refine brands seamlessly using AI-powered tools.</p>
        </div>
        <div class="frame-5">
          <div class="menu-dashboard">
            <div class="frame-6">
              <img class="img" src="https://c.animaapp.com/ct0n38lD/img/group-11@2x.png" />
              <div class="frame-7">
                <div class="frame-8">
                  <div class="text-wrapper-7">New Assessment</div>
                  <p class="text-wrapper-8">
                    Assess brand identity, performance, and positioning with AI-driven insights.
                  </p>
                </div>
                <img class="ARROW" src="https://c.animaapp.com/ct0n38lD/img/arrow.svg" />
              </div>
            </div>
          </div>
          <div class="frame-wrapper">
            <div class="div-wrapper">
              <div class="frame-6">
                <img class="vector-2" src="https://c.animaapp.com/ct0n38lD/img/vector-1.svg" />
                <div class="frame-7">
                  <div class="frame-8">
                    <div class="text-wrapper-9">Manage Clients</div>
                    <p class="text-wrapper-6">
                      View and update brand assessments easily. Keep insights accurate and up to date.
                    </p>
                  </div>
                  <img class="ARROW-2" src="img/ARROW.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
